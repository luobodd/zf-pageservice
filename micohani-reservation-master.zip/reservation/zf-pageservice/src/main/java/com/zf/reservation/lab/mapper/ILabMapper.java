package com.zf.reservation.lab.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zf.reservation.lab.entity.Lab;

@Repository
public interface ILabMapper extends BaseMapper<Lab>{
}
