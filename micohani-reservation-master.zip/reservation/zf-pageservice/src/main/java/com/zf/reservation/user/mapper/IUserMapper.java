package com.zf.reservation.user.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zf.reservation.user.entity.Teacher;

import org.springframework.stereotype.Repository;

@Repository
public interface IUserMapper extends BaseMapper<Teacher> {
}
