package com.zf.reservation.user.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zf.reservation.user.entity.UserErrorLogin;

public interface IUserErrorLoginService extends IService<UserErrorLogin> {
}
